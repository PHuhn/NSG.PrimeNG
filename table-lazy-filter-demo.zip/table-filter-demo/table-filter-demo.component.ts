// angular
import { Component, OnInit } from '@angular/core';
// libraries
import { SelectItem } from 'primeng/components/common/selectitem';
import { FilterMetadata } from 'primeng/components/common/filtermetadata';
import { LazyLoadEvent } from 'primeng/api';
// project
import { Car } from './car';
import { CarService } from './car-service';
//
@Component({
  selector: 'app-table-filter-demo',
  templateUrl: './table-filter-demo.component.html',
  styleUrls: ['./table-filter-demo.component.css']
})
//
export class TableFilterDemoComponent implements OnInit {
    //
	datasource: Car[];
	totalRecords: number;
	loading: boolean;
    //
	cars: Car[];
    //
	cols: any[];
	// filters
	brands: SelectItem[];
	colors: SelectItem[];
	yearFilter: number;
	yearTimeout: any;
    //
	constructor(private _carService: CarService) { }
    //
	ngOnInit() {
		//
		this._carService.getCarsHuge().then(cars => {
			this.datasource = cars;
			this.cars = cars
			this.totalRecords = this.datasource.length;
		});
		this.brands = [
			{ label: 'All Brands', value: null },
			{ label: 'Audi', value: 'Audi' },
			{ label: 'BMW', value: 'BMW' },
			{ label: 'Fiat', value: 'Fiat' },
			{ label: 'Honda', value: 'Honda' },
			{ label: 'Jaguar', value: 'Jaguar' },
			{ label: 'Mercedes', value: 'Mercedes' },
			{ label: 'Renault', value: 'Renault' },
			{ label: 'VW', value: 'VW' },
			{ label: 'Volvo', value: 'Volvo' }
		];
		this.colors = [
			{ label: 'White', value: 'White' },
			{ label: 'Green', value: 'Green' },
			{ label: 'Silver', value: 'Silver' },
			{ label: 'Black', value: 'Black' },
			{ label: 'Red', value: 'Red' },
			{ label: 'Maroon', value: 'Maroon' },
			{ label: 'Brown', value: 'Brown' },
			{ label: 'Orange', value: 'Orange' },
			{ label: 'Yellow', value: 'Yellow' },
			{ label: 'Blue', value: 'Blue' }
		];
		this.cols = [
			{ field: 'vin', header: 'Vin' },
			{ field: 'year', header: 'Year' },
			{ field: 'brand', header: 'Brand' },
			{ field: 'color', header: 'Color' }
		];
        this.loading = true;
	}
    //
	onYearChange(event, dt) {
		if (this.yearTimeout) {
			clearTimeout(this.yearTimeout);
		}
		this.yearTimeout = setTimeout(() => {
			dt.filter(event.value, 'year', 'gt');
		}, 250);
	}
	//
	loadCarsLazy(event: LazyLoadEvent) {  
		this.loading = true;
        //
		//in a real application, make a remote request to load data using state metadata from event
		//event.sortField = Field name to sort with
		//event.sortOrder = Sort order as number, 1 for asc and -1 for dec
		//imitate db connection over a network
		setTimeout(() => {
			if (this.datasource) {
				let filtered: Car[] = this.datasource;
				if( event.filters ) {
					for (let key in event.filters) {
						const filter: FilterMetadata = event.filters[key];
						switch( filter.matchMode.toLowerCase() ) { 
							case 'equals': {
								filtered = filtered.filter( el => { return el[key] === filter.value });
								break;
							}
							case 'gt': {
								filtered = filtered.filter( el => { return el[key] > filter.value });
								break;
							}
							case 'lt': {
								filtered = filtered.filter( el => { return el[key] < filter.value });
								break;
							}
							case 'startswith': {
								const _len = filter.value.length;
								filtered = filtered.filter( el => { return el[key].substring(0, _len) === filter.value });
								break;
							}
							case 'in': {
								filtered = filtered.filter( el => { return filter.value.includes( el[key] ); });
								break;
							}
							default: {
								console.log(`matchMode not found: ${filter.matchMode}`);
								break;
							} 
						}
					}
				}
				this.totalRecords = filtered.length;
				this.cars = filtered.slice(event.first, (event.first + event.rows));
				this.loading = false;
			}
		}, 100);
	}
	//
}
//
